<?php
session_start();
require_once('connection.php');

function logout() {
		$_SESSION = array();
		session_destroy();
	}

if(isset($_POST['action']) && $_POST['action'] == 'register')
	{
    	foreach ($_POST as $name => $value) 
    	{
	        if(empty($value))
	        {
	            $_SESSION['error'][$name] = "sorry, " . $name . " cannot be blank";
	        }
        	else
        	{
	            switch ($name) 
	            {
	                case 'first_name':
	                case 'last_name':
                        if(is_numeric($value))
                        {
                            $_SESSION['error'][$name] = $name . ' cannot contain numbers';
                        }
	                break;
	                case 'email':
                        if(!filter_var($value, FILTER_VALIDATE_EMAIL))
                        {
                            $_SESSION['error'][$name] = $name . ' is not a valid email';
                        }
	                break;
	                case 'password':
                        $password = $value;
                        if(strlen($value) < 5)
                        {
                            $_SESSION['error'][$name] = $name . ' must be greater than 5 characters';
                        }
	                break;
	                case 'confirm_password':
                        if($password != $value)
                        {
                            $_SESSION['error'][$name] = 'Passwords do not match';
                        }
	                break;
	            }
            }        
        }
        $_SESSION['first_name'] = $_POST['first_name'];
        $_SESSION['last_name'] = $_POST['last_name'];
        $_SESSION['email'] = $_POST['email'];
        $_SESSION['birthdate'] = $_POST['birthdate'];
        header('Location: index.php');
    }
    else if (isset($_POST['action']) && $_POST['action'] == 'login')
    {
    	if (empty($_POST['email']) || empty($_POST['password'])) 
    	{
    		   	$_SESSION['login_error']['message'] = "Email or Password cannot be blank";
    		   	header('Location: index.php');
	    }
	    else
	    {
	    	$query = "SELECT id, password
                      FROM users
                      WHERE email = '".$_POST['email']."'";
                $result = mysqli_query($connection, $query);
                $row = mysqli_fetch_assoc($result);

	    	if (empty($row)) {
	    		$_SESSION['login_error']['message'] = 'Could not find Email in database';
	    		header('Location: index.php');
	    		exit;
	    	}
	    	else
	    	{
	    		if (crypt($_POST['password'], $row['password']) != $row['password']) {
	    			$_SESSION['login_error']['message'] = 'incorrect password';
	    			header('Location: index.php');
	    			exit;
	    		}
	    		else
	    		{
	    			$_SESSION['user_id'] = $row['id'];
	    			header('Location: profile.php?id=' . $row['id']);
	    			exit;
	    		}
	    	}
	    }
    }  
    else if (isset($_GET['logout']))
    {
    	logout();
    	header('Location: index.php');
    	exit;
    }      

	if (!isset($_SESSION['error']) && !isset($_SESSION['login_error'])) {

		$salt = bin2hex(openssl_random_pseudo_bytes(22));
		$hash = crypt($_POST['password'], $salt);

		$query = "INSERT INTO users (first_name, last_name, email, password, birthdate, updated_at, created_at)
				  VALUES ('" . mysqli_real_escape_string($connection, $_POST['first_name']) . "', '" . mysqli_real_escape_string($connection, $_POST['last_name']) . "', '" . mysqli_real_escape_string($connection, $_POST['email']) . "', '" . $hash . "', '" . mysqli_real_escape_string($connection, $_POST['birthdate']) . "', NOW(), NOW())";
		$_SESSION['message'] = $_SESSION['first_name'] . ' your account was created successfully!';
		mysqli_query($connection, $query);

		$user_id = mysqli_insert_id($connection);

		$_SESSION['user_id'] = $user_id;

		header('Location: profile.php?id=' .$user_id);
		exit;
	}
?>